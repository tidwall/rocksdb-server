<?php

phutil_register_library('arcanist_util', __FILE__);
